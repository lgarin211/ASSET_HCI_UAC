function powliwing(){
    document.getElementById("menunya").classList.toggle("posito");
    document.getElementById("account").classList.toggle("posito");
}
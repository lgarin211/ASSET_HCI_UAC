// windows onload
window.onload = function() {
    // setTimeout
    setTimeout(function() {
        // get the loading div
        var loading = document.getElementById("load");
        // set the display to none
        loading.style.display = "none";
        // Transisi
    }, 1000);
}